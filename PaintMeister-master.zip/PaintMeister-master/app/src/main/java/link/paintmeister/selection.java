package link.paintmeister;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class selection extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading_screen);
        Bundle extras = this.getIntent().getExtras();
        String name =  "-";
        if(extras != null){
            name = extras.getString("File_name");

            Toast.makeText(this, name, Toast.LENGTH_LONG).show();
        }
    }
}
